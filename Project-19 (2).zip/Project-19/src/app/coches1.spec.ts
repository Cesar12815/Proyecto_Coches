import { Coches1 } from './coches1';

describe('Coches1', () => {
  it('should create an instance', () => {
    expect(new Coches1()).toBeTruthy();
  });
});
