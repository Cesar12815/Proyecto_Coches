import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
coches : any = { marca : '', modelo : '', modelo_año:'',color : '', precio : ''}
autor : any =  {nombre : 'Cesar', apellido : 'Quintero', curso : 'Programacion 3', universidad : 'Corhuila'}
autor2 : any = {nombre : 'Julian', apellido : 'Garcia', curso : 'Programacion 3', universidad : 'Corhuila'}
}
