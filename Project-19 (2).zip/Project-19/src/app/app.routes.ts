import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CochesComponent } from './coches/coches.component';

export const routes: Routes = [
    {path : 'header', component : HeaderComponent},
    {path : 'footer', component : FooterComponent},
    {path : "coches", component : CochesComponent}
];
