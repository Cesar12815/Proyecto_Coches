import { Component, OnInit } from '@angular/core';
import { Coches } from './coches';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-tareas',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './coches.component.html',
  styleUrl: './coches.component.css'
})
export class CochesComponent implements OnInit  {
  Coche : Coches[]=[
  {marca : 'Toyota', modelo: 'Corolla', modelo_año: 2023, color : 'Blanco', precio: 20000},
  {marca : 'Honda', modelo: 'Civic', modelo_año: 2022, color : 'Negro', precio: 22000},
  {marca : 'Tesla', modelo: 'Model 3', modelo_año: 2023, color : 'Rojo', precio: 35000},
  ]
  
  ngOnInit(): void {
   
  }

}