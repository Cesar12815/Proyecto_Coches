export class Coches { 
    marca : String | undefined ;
    modelo!: String;
    modelo_año!: number;
    color!: String;
    precio!: number;
    
}